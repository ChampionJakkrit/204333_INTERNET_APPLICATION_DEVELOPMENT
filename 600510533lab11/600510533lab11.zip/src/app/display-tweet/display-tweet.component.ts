import { Component, OnInit, Input } from '@angular/core';
import { Tweet } from '../tweet';
import { AuthService } from '../auth.service';
import { AngularFireAuth } from "@angular/fire/auth";

@Component({
  selector: 'app-display-tweet',
  templateUrl: './display-tweet.component.html',
  styleUrls: ['./display-tweet.component.css']
})
export class DisplayTweetComponent implements OnInit {

  constructor( 
    private auth : AuthService,
    private afAuth : AngularFireAuth
  ) { }

  @Input() tweet : Tweet;
  isLoggedIn;
  name;

  ngOnInit() {
    this.afAuth.auth.onAuthStateChanged((user) => {
      if (user) {
        this.isLoggedIn = true;
        this.name = user.email;
      } else {
        this.isLoggedIn = false;
        this.name = undefined;
      }
    });
  }

}