import { Injectable } from '@angular/core';
import { InMemoeyDbService } from 'angular-in-memory-web-api';

import { Tweet } from './tweet';
import { Upvote } from './upvote';

@Injectable({
  providedIn: 'root',
})
export class InMemoryDataService implements InMemoryDbService {

  createDb() {
    const tweets : Tweet[] = [{
      id:0,
      name:'Guest',
      msg:'Hello',
      date:new Date(2020,1,14)
    }];
    const upvotes : Upvote[]= [{
      id:0,
      "Guest":0,
    }]
    return {tweets, upvotes};
  }
  constructor() { }

}