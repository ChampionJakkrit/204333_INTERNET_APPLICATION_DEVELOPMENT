export class Voter {
  name:string;
  vote:number;
}