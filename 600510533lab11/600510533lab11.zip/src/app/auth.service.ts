import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn:'root'
})
export class AuthService {

  constructor() {
    if (localStorage.getItem("isLoggedIn")==="true")
      this.isLoggedIn.next(true);
  }

  public isLoggedIn = new Subject<boolean>();
  public username = new Subject<string>();

  login(username:string) {
    localStorage.setItem('isLoggedIn', "true");  
    localStorage.setItem('username', username);
    this.isLoggedIn.next(true);
    this.username.next(username);
  }

  logout() {
    localStorage.setItem('isLoggedIn','false'); 
    localStorage.removeItem('username');
    this.isLoggedIn.next(false);
    this.username.next(undefined);
  }

}