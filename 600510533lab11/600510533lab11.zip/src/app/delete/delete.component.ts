import { Component, OnInit, Input } from '@angular/core';
import { FirebaseService } from '../firebase.service';
import { AngularFireAuth } from "@angular/fire/auth";

@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent implements OnInit {

  constructor(
    private fServ : FirebaseService,
    private afAuth : AngularFireAuth
  ) { }

  @Input() voteId : string;
  isLoggedIn : boolean = false;
  username: string;

  ngOnInit() {
    this.afAuth.auth.onAuthStateChanged(user => {
      if (user) {
        var displayName = user.displayName;
        var email = user.email;
        var emailVerified = user.emailVerified;
        var photoURL = user.photoURL;
        var isAnonymous = user.isAnonymous;
        var uid = user.uid;
        var providerData = user.providerData;
        this.username = email;
        this.isLoggedIn = true;
      } else {
        this.username = "";
        this.isLoggedIn = false;
      }
    });
  }

  delete() {
    this.fServ.deleteTweet(this.voteId);
  }

}