import { Component, OnInit } from '@angular/core';
import { actors } from '../actors';

@Component({
  selector: 'actor-list',
  templateUrl: './actor-list.component.html',
  styleUrls: ['./actor-list.component.css']
})
export class ActorListComponent implements OnInit {

  acts = actors;

  constructor() { }

  ngOnInit() {
  }

}