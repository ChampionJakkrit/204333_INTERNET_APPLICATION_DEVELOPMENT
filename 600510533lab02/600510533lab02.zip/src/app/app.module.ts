import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { HelloComponent } from './hello.component';
import { MovieListComponent } from './movie-list/movie-list.component';
import { ActorListComponent } from './actor-list/actor-list.component';

@NgModule({
  imports:      [ BrowserModule, FormsModule ], // เหมือน include
  declarations: [ AppComponent, HelloComponent, MovieListComponent, ActorListComponent ], //  ประกอบไปด้วยไปด้วย Components, Directives และ Pipes
  bootstrap:    [ AppComponent ] // การกำหนด component หลัก
})
export class AppModule { } // แปลง class ให้เป็น module
