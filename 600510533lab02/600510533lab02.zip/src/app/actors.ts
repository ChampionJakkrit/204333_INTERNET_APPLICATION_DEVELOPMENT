export const actors = [
  {
    firstName: 'Robert Downey',
    lastName: 'Jr.',
    gender: 'M'
  },
  {
    firstName: 'Emma',
    lastName: 'Watson',
    gender: 'F'
  },{
    firstName: 'Chris',
    lastName: 'Hemsworth',
    gender: 'M'
  },{
    firstName: 'Angelina',
    lastName: 'Jolie',
    gender: 'F'
  },{
    firstName: 'Tom',
    lastName: 'Cruise',
    gender: 'M'
  },{
    firstName: 'Leonardo',
    lastName: 'DiCaprio',
    gender: 'M'
  },{
    firstName: 'Georgie',
    lastName: 'Henley',
    gender: 'F'
  },{
    firstName: 'Kirsten',
    lastName: 'Dunst',
    gender: 'F'
  },
];