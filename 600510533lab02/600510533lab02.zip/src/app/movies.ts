export const movies = [
  {
    name: 'Titanic',
    year: 1997,
    genre: 'drama'
  },
  {
    name: 'Avatar',
    year: 2012,
    genre: 'action'
  },
  {
    name: 'Aventure',
    year: 2014,
    genre: 'action'
  },
  {
    name: 'Shooter',
    year: 1998,
    genre: 'action'
  }
];