import { Component, Input } from '@angular/core';

@Component({
  selector: 'hello', // ชื่อแท็ก
  template: `<h1>Hello {{name}}!</h1>`, // สิ่งที่จะแสดงผล
  styles: [`h1 { font-family: Lato; }`]
})
export class HelloComponent  {
  @Input() name: string; // สร้างตัวแปรชื่อ name
}
