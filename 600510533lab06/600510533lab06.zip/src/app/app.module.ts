import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClientInMemoryWebApiModule } from 'angular-in-memory-web-api';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';


import { AppComponent } from './app.component';
import { HelloComponent } from './hello.component';
import { InMemoryDataService } from './in-memory-data.service';
import { TweetService } from './tweet.service';
import { DisplayTweetComponent } from './display-tweet/display-tweet.component';
import { AddTweetComponent } from './add-tweet/add-tweet.component';

@NgModule({
  imports:      [ BrowserModule, FormsModule, HttpClientModule, 
  HttpClientInMemoryWebApiModule.forRoot(InMemoryDataService,{dataEncapsulation:false}),
  ReactiveFormsModule,
  RouterModule.forRoot([
    { path: '', component: DisplayTweetComponent },
    { path: 'tweet', component: AddTweetComponent }
  ]),],
  declarations: [ AppComponent, HelloComponent, DisplayTweetComponent, AddTweetComponent ],
  bootstrap:    [ AppComponent ],
  providers: [InMemoryDataService, TweetService]
})
export class AppModule { }
