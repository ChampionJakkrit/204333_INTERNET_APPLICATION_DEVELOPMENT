import { Component, OnInit } from '@angular/core';
import { TweetService } from '../tweet.service';
import { Tweet } from '../tweet';

@Component({
  selector: 'app-display-tweet',
  templateUrl: './display-tweet.component.html',
  styleUrls: ['./display-tweet.component.css']
})
export class DisplayTweetComponent implements OnInit {

  constructor(
    private tServ : TweetService
  ) { }

  tweets : Tweet[]; // local storege

  ngOnInit() {
    this.tServ.getTweets().subscribe(val => this.tweets = val);
  }

  delete(id: number) {
    const url = `api/tweets/${id}`;
    this.tServ.deleteTweet(url).subscribe();
    this.tServ.getTweets()
    .subscribe(tweets => this.tweets = tweets);
  }
}