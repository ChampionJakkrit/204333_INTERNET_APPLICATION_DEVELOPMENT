import { Injectable } from '@angular/core';
import { InMemoryDbService } from 'angular-in-memory-web-api';
import { Tweet } from './tweet';


@Injectable({
  providedIn: 'root',
})
export class InMemoryDataService implements InMemoryDbService {

  createDb() {
    const tweets : Tweet[] = [{
      id:0,
      name: 'Chxmpionnn',
      msg: 'Hello',
      date: new Date()
    }]
    return {tweets};
  }

  constructor() { }

}