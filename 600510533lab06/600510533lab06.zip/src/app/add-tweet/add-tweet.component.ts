import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';

import { TweetService } from '../tweet.service';

@Component({
  selector: 'app-add-tweet',
  templateUrl: './add-tweet.component.html',
  styleUrls: ['./add-tweet.component.css']
})
export class AddTweetComponent implements OnInit {

  constructor(
    private tServ: TweetService,
    private router: Router
  ) { }

  form = new FormGroup({
    name : new FormControl(''),
    msg : new FormControl(''),
  });

  ngOnInit() {}

  onSubmit() {
    this.tServ.addTweet(
    this.form.value.name,
    this.form.value.msg
    ).subscribe();
    this.router.navigate(['']);
  }
}