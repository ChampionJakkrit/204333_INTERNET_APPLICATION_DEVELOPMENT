import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { Product } from '../products';
import { CartService } from '../cart.service';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {
  product;
  constructor(
    private rounte: ActivatedRoute,
    private cartService: CartService,
    private productService: ProductService,
  ) { }
    
  ngOnInit() { // ดึงข้อมูลจาก service มาเก็บไว้ที่นี่
    const id = +this.rounte.snapshot.paramMap.get('productId');
    this.productService.getProduct(id)
    .subscribe(product => this.product = product);
  }
  addToCart(product) {
    window.alert('Your product has been added to the cart!');
    this.cartService.addToCart(product);
    console.log(this.cartService.getItems());
  }
}