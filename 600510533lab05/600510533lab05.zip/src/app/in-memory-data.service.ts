import { Injectable } from '@angular/core';
import { InMemoryDbService} from 'angular-in-memory-web-api';
import { Product } from 'product';

@Injectable({
  providedIn: 'root',
})
export class InMemoryDataService implements InMemoryDbService {

  createDb() {
    const products = [
      {
        id: 0,
        name: 'iphone 11',
        price: 24900,
      },
      {
        id: 1,
        name: 'iphone 11 pro',
        price: 35900,
      },
      {
        id: 2,
        name: 'iphone 11 pro max',
        price: 39900,
      }         
    ];
    return {products};

  }

}