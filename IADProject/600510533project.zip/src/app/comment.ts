export class Comment {
  id: string;
  name: string;
  msg: string;
  date: Date;
}