import { Injectable } from '@angular/core';
import { AngularFireAuth } from "@angular/fire/auth";
import { AngularFirestore } from "@angular/fire/firestore";
// import * as firebase from "firebase";

@Injectable()
export class AuthService {

  public isLoggedIn: boolean;

  constructor(
    private fireAuth: AngularFireAuth,
    private fireStore: AngularFirestore
  ) {
    this.isLoggedIn = false;
   }

  getCerrentUser() {
    return this.fireAuth.auth.currentUser.uid
  }

  setUser(userId: string) {
    const ref = this.fireStore.doc(`favorite/${userId}`)
    const doc = {
      movieList: [],
      uId: userId
    }
    return ref.set(doc,{merge:true})
  }

}