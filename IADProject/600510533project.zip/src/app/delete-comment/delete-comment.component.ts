import { Component, OnInit, Input } from '@angular/core';
import { FirebaseService } from '../firebase.service';

@Component({
  selector: 'app-delete-comment',
  templateUrl: './delete-comment.component.html',
  styleUrls: ['./delete-comment.component.css']
})
export class DeleteCommentComponent implements OnInit {

  constructor(
    private fServ : FirebaseService
  ) { }

  @Input() commentId : string;

  ngOnInit() {
  }

  delete() {
    this.fServ.deleteComment(this.commentId);
  }

}