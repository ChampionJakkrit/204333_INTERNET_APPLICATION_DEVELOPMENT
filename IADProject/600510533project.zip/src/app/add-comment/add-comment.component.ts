import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators} from '@angular/forms';
import { Router } from '@angular/router';
import { FirebaseService } from '../firebase.service';
import { AngularFireAuth } from '@angular/fire/auth';

@Component({
  selector: 'app-add-comment',
  templateUrl: './add-comment.component.html',
  styleUrls: ['./add-comment.component.css']
})
export class AddCommentComponent implements OnInit {

  constructor(
    private router : Router,
    private fServ : FirebaseService,
    private afAuth : AngularFireAuth
  ) { }

  form = new FormGroup({
    msg : new FormControl('')
  });
  name : string;

  ngOnInit() {
    this.afAuth.auth.onAuthStateChanged((user) => {
      if (user) {
        this.name = user.email;
      } else {
        this.name = undefined;
      }
    });
  }

  onSubmit() {
    this.fServ.addComment(this.name,this.form.value.msg);
    this.router.navigate(['details']);
  }

}