import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.css"]
})
export class HomeComponent implements OnInit {
  sortOption: string;
  searchText: string;
  key: string = "name";
  reverse: boolean = false;

  constructor() {
  }

  sort(key, reverse) {
    console.log('key');
    this.key = key;
    this.reverse = reverse;
  }
  p: number = 1;

  ngOnInit() {}
}
