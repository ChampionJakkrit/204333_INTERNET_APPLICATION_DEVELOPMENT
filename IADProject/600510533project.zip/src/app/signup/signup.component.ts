import { Component, OnInit } from '@angular/core';
import { FirebaseService } from '../firebase.service.ts'
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  email : string;
  password: string;
  confirmPassword: string;

  constructor(
    private firebaseService : FirebaseService,
    private router: Router
  ) { }

  ngOnInit() {
  }

  onRegister() {
    if(this.password !== this.confirmPassword){
      alert('password not match');
      this.router.navigate(['signup']);
      return;
    }
    this.firebaseService.register(this.email, this.password);
    this.router.navigate(['login'])
  }

  goLogin() {
    this.router.navigate(['login'])
  }

}