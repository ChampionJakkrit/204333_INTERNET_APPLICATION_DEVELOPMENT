import { Component, OnInit } from '@angular/core';
import { FirebaseService } from "../firebase.service";
import { AngularFireStorage } from "@angular/fire/storage";
import { Router } from '@angular/router';
import { Observable } from "rxjs";
import { ActivatedRoute } from '@angular/router';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { AuthService } from '../auth.service';


@Component({
  selector: 'app-movie-details',
  templateUrl: './movie-details.component.html',
  styleUrls: ['./movie-details.component.css']
})
export class MovieDetailsComponent implements OnInit {
  movie: any;
  loading: boolean=true;
  constructor(
    private fireStorage: AngularFireStorage,
    private firebaseService: FirebaseService,
    private router: Router,
    private activeRoute: ActivatedRoute,
    private domSanitizer: DomSanitizer,
    private auth: AuthService

  ) { }

  ngOnInit() {
    this.activeRoute.params.subscribe( params => {
      console.log(params.movieId)
      this.firebaseService.getMovieFromId(params.movieId).subscribe(res => {
        this.movie = res
        this.loading = false
        console.log(this.movie)
      })
    }) 
  }

  getSaveUrl(url: string): SafeResourceUrl {
    return this.domSanitizer.bypassSecurityTrustResourceUrl(url)
  }

  onAddFavorite() {
    this.firebaseService.addFavorite(this.movie.id, this.auth.getCerrentUser())
    window.alert('This movie has been added to favorite!');
  }
}