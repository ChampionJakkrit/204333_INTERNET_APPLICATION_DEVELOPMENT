export const environment = {
  firebaseConfig : {
    apiKey: "AIzaSyDTszLoiCbfzHR-CDfo9qKs0w9zPfenESE",
    authDomain: "project-iad-ecdb2.firebaseapp.com",
    databaseURL: "https://project-iad-ecdb2.firebaseio.com",
    projectId: "project-iad-ecdb2",
    storageBucket: "project-iad-ecdb2.appspot.com",
    messagingSenderId: "364247203695",
    appId: "1:364247203695:web:429183307de27656b0729a",
    measurementId: "G-X1PCXM1S71"
  }
}
