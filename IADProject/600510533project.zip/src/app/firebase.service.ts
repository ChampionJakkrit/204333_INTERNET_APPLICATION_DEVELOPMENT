import { Injectable } from "@angular/core";
import { AngularFireAuth } from "@angular/fire/auth";
import { AngularFirestore } from "@angular/fire/firestore";
import { Observable, of } from "rxjs";
import { firestore } from "firebase";
import * as firebase from 'firebase/app';

@Injectable({
  providedIn: "root"
})
export class FirebaseService {
  constructor(
    private fireAuth: AngularFireAuth,
    private database: AngularFirestore
  ) {}

  register(email: string, password: string) {
    this.fireAuth.auth
      .createUserWithEmailAndPassword(email, password)
      .then(res => {
        alert("Your registation is succesful");
      })
      .catch(function(error) {
        var errorCode = error.code;
        var errorMessage = error.message;
        alert(errorMessage);
      });
  }

  login(email: string, password: string) {
    return this.fireAuth.auth.signInWithEmailAndPassword(email, password);
  }

  getMovie(): Observable<any> {
    var docRef = this.database.collection("movie");
    return docRef.valueChanges();
  }

  getMovieFromId(movieId: string): Observable<any> {
    return this.database.doc(`movie/${movieId}`).valueChanges()
  }

  addFavorite(movieId: string, userId: string) {
    const ref = this.database.doc(`favorite/${userId}`)
    console.log(movieId)
    return ref.update({
      movieList: firestore.FieldValue.arrayUnion(movieId)
    })
  }
  
  getMovieFromMovieList(movieList: String[]) {
    if (movieList.length == 0) 
      return of([])
    return this.database.collection(`movie` ,ref => ref.where('id', 'in', movieList)).valueChanges()
  }

  getFavorite(userId: String) {
    return this.database.doc(`favorite/${userId}`).valueChanges()
  }

  deleteFavorite(movieId: string, userId: string) {
    const ref = this.database.doc(`favorite/${userId}`)
    console.log(movieId)
    return ref.update({
      movieList: firestore.FieldValue.arrayRemove(movieId)
    })
  }

  addComment(val1 : string, val2 : string) {
    let comment = {
      name: val1,
      msg: val2,
      date: firebase.firestore.Timestamp.now(),
    };
    return this.database.collection('comment').add(comment);
  }

  getComment() {
    return this.database.collection('comment').snapshotChanges();
  }

  deleteComment(id : string) {
    this.database.collection('comment').doc(id).delete();
  }

}
