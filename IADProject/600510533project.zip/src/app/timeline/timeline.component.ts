import { Component, OnInit } from '@angular/core';
import { Comment } from '../comment';
import { FirebaseService } from '../firebase.service';

@Component({
  selector: 'app-timeline',
  templateUrl: './timeline.component.html',
  styleUrls: ['./timeline.component.css']
})
export class TimelineComponent implements OnInit {

  constructor(
    private fServ : FirebaseService
  ) { }

  comment : Comment[];

  ngOnInit() {
    this.fServ.getComment().subscribe(val => {
      this.comment = val.map( e => {
        return {
          id: e.payload.doc.id,
          ...(e.payload.doc.data() as object)
        } as Comment
      })
    });
  }


}