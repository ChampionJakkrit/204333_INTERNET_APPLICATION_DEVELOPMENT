import { Component, OnInit, Input } from "@angular/core";
import { FirebaseService } from "../firebase.service";
import { AngularFirestore } from "@angular/fire/firestore";
import { AngularFireStorage } from "@angular/fire/storage";
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';
import { Observable } from "rxjs";

@Component({
  selector: "app-movie-list",
  templateUrl: "./movie-list.component.html",
  styleUrls: ["./movie-list.component.css"]
})
export class MovieListComponent implements OnInit {
  movies: any;
  @Input() searchText: string;
  @Input() key: string;
  @Input() reverse: boolean;
  constructor(
    private firebaseService: FirebaseService,
    private fireStorage: AngularFireStorage,
    private auth: AuthService,
    private router: Router
    ) {
    this.movies = this.firebaseService.getMovie();
  }

  ngOnInit() {
    this.auth.getCerrentUser()
  }

  goDetails(movieId: string) {
    if (this.auth.isLoggedIn === true) {
      this.router.navigate([`details/${movieId}`]);
    }
    else {
      this.router.navigate(['login'])
    }
  }

  }

  

