import { Component, OnInit } from '@angular/core';
import { FirebaseService } from "../firebase.service";
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-favorite',
  templateUrl: './favorite.component.html',
  styleUrls: ['./favorite.component.css']
})
export class FavoriteComponent implements OnInit {
  faveriteList: any;
  constructor(
    private fireService: FirebaseService,
    private auth: AuthService
  ) { }

  ngOnInit() {
    this.fireService.getFavorite(this.auth.getCerrentUser()).subscribe( res => {
      this.faveriteList = this.fireService.getMovieFromMovieList(res.movieList)
      })
  }

  onDeleteFavorite(movieId: string) {
    this.fireService.deleteFavorite(movieId, this.auth.getCerrentUser())
  }
}