import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { HelloComponent } from './hello.component';
import { TopBarComponent } from './top-bar/top-bar.component';
import { MovieListComponent } from './movie-list/movie-list.component';
import { MovieDetailsComponent } from './movie-details/movie-details.component';
import { FavoriteComponent } from './favorite/favorite.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { AuthService } from './auth.service';
import { AngularFireAuthModule } from '@angular/fire/auth';
import { AngularFireModule } from '@angular/fire';
import { AngularFireStorageModule} from '@angular/fire/storage';
import { AngularFirestoreModule, AngularFirestore} from '@angular/fire/firestore' 
import { environment } from './environment';
import { FirebaseService } from './firebase.service';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { Ng2OrderModule } from 'ng2-order-pipe';
import { AddCommentComponent } from './add-comment/add-comment.component';
import { DeleteCommentComponent } from './delete-comment/delete-comment.component';
import { DisplayCommentComponent } from './display-comment/display-comment.component';
import { TimelineComponent } from './timeline/timeline.component'; 

@NgModule({
  imports:      [ 
    Ng2SearchPipeModule,
    Ng2OrderModule,
    BrowserModule,
    FormsModule,
    AngularFireStorageModule,
    AngularFireAuthModule,
    AngularFirestoreModule,
    ReactiveFormsModule,
    AngularFireModule.initializeApp(environment.firebaseConfig),
    RouterModule.forRoot([
      {path:'', component:HomeComponent, pathMatch: 'full'},
      {path:'favorite', component:FavoriteComponent},
      {path:'login', component:LoginComponent},
      {path:'signup', component:SignupComponent},
      {path:'details/:movieId', component:MovieDetailsComponent}
    ]),
     ],
  declarations: [ AppComponent, HelloComponent, TopBarComponent, MovieListComponent, MovieDetailsComponent, FavoriteComponent, HomeComponent, LoginComponent, SignupComponent, AddCommentComponent, DeleteCommentComponent, DisplayCommentComponent, TimelineComponent ],
  bootstrap:    [ AppComponent ],
  providers: [AuthService, FirebaseService]
})
export class AppModule { }
