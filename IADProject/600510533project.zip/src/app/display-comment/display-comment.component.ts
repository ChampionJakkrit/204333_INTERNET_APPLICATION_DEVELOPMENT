import { Component, OnInit, Input } from '@angular/core';
import { Comment } from '../comment';
import { AngularFireAuth } from '@angular/fire/auth';

@Component({
  selector: 'app-display-comment',
  templateUrl: './display-comment.component.html',
  styleUrls: ['./display-comment.component.css']
})
export class DisplayCommentComponent implements OnInit {

  constructor(
    private afAuth : AngularFireAuth
  ) { }

  @Input() comment : Comment;
  isLoggedIn;
  name;

  ngOnInit() {
    this.afAuth.auth.onAuthStateChanged((user) => {
      if (user) {
        this.isLoggedIn = true;
        this.name = user.email;
      } else {
        this.isLoggedIn = false;
        this.name = undefined;
      }
    });
  }

}