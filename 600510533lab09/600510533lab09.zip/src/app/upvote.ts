export class Upvote {
  id: number;
  [username:string] :number;

}