export const environment = {
  firebaseConfig : {
    apiKey: "AIzaSyAZ1xSe8BErmYc17iuJUlwpgzU8Gz0y7gk",
    authDomain: "example-5ceca.firebaseapp.com",
    databaseURL: "https://example-5ceca.firebaseio.com",
    projectId: "example-5ceca",
    storageBucket: "example-5ceca.appspot.com",
    messagingSenderId: "147200297839",
    appId: "1:147200297839:web:66cc40ee1e28189e6ab69a",
    measurementId: "G-XP40CNZGRT"
  }
}
