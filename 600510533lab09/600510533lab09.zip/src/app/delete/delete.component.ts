import { Component, OnInit, Input } from '@angular/core';
import { FirebaseService } from '../firebase.service';
import { Tweet } from '../tweet';

@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent implements OnInit {
  @Input() id: number;

  tweets : Tweet[];

  constructor(
    private fServ : FirebaseService
  ) { }

  ngOnInit() {
  }
  
  onDelete() {
    this.fServ.deleteTweet(this.id).subscribe();
  }

}