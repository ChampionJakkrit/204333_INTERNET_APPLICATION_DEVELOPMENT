export class Tweet {
  id: string;
  name: string;
  msg: string;
  date: Date;
}