import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Tweet } from '../tweet';
import { FirebaseService } from '../firebase.service';

@Component({
  selector: 'app-add-tweet',
  templateUrl: './add-tweet.component.html',
  styleUrls: ['./add-tweet.component.css']
})
export class AddTweetComponent implements OnInit {

  constructor(
    private fServ : FirebaseService
  ) { }

  form = new FormGroup({
    msg : new FormControl(''),
  });

  name : string;

  ngOnInit() {
    this.name= localStorage.getItem("username");
  }

  onSubmit() {
    this.fServ.addTweet(this.name,this.form.value.msg);
  }

}