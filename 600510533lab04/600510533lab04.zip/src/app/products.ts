export const products = [
  {
    name: 'iPhone 11',
    price: 24900,
    description: 'Basic model'
  },
  {
    name: 'iPhone 11 Pro',
    price: 35900,
    description: 'High-end model'
  },
  {
    name: 'iPhone 11 Pro Max',
    price: 39900,
    description: 'High-end model with large screen'
  }
];


/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/