import { Component, OnInit } from '@angular/core';
import { Tweet } from '../tweet';
import { AuthService } from '../auth.service';
import { TweetService } from '../tweet.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-display-tweet',
  templateUrl: './display-tweet.component.html',
  styleUrls: ['./display-tweet.component.css']
})
export class DisplayTweetComponent implements OnInit {

  tweets : Tweet[];

  constructor(
    private auth : AuthService,
    private tServ : TweetService,
    private router : Router
  ) { }

  name : string;
  isLoggedIn : boolean;

  ngOnInit() {
    this.tServ.getTweets().subscribe(tweets => this.tweets = tweets);
    this.name = localStorage.getItem("username");
    this.isLoggedIn = (localStorage.getItem("isLoggedIn")) == "true";
    this.auth.isLoggedIn.subscribe(val => this.isLoggedIn = val);
  }


  delete(id:number) {
    const url = `api/tweets/${id}`;
    this.tServ.deleteTweet(url).subscribe();
    this.tServ.getTweets()
    .subscribe(tweets => this.tweets = tweets);
  }
}