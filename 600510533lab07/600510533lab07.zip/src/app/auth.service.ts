import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn:'root'
})
export class AuthService {

  constructor() { }

  public isLoggedIn = new Subject<boolean>();

  login(username:string) {
    // localStorage เมื่อ logout 
    localStorage.setItem('isLoggedIn',"true");
    localStorage.setItem('username',username);
    this.isLoggedIn.next(true);
  }

  logout() {
    localStorage.setItem('isLoggedIn',"false");
    localStorage.removeItem('username');
    this.isLoggedIn.next(false);
  }

}