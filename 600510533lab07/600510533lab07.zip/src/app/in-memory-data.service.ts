import { Injectable } from '@angular/core';
import { InMemoryDbService } from 'angular-in-memory-web-api0';

import { Tweet } from './tweet';

@Injectable({
  providedIn: 'root',
})

export class InMemoryDataService implements InMemoryDataService {

  createDb(){
    const tweets : Tweet[] = [{
      id:0,
      name:'Chxmpion',
      msg: 'Hello my friend!',
      date : new Date()
    }];
    return {tweets};
  }

  constructor() { }

}