import { Component, OnInit } from '@angular/core';
import { item } from '../item.ts';

@Component({
  selector: 'app-items',
  templateUrl: './items.component.html',
  styleUrls: ['./items.component.css']
})
export class ItemsComponent implements OnInit {

  items : Item[] = [
  {id: 1, name: "Apple", quantity: 1, unit: "price"},
  {id: 2, name: "Banana", quantity: 0.5, unit: "dozen"}
  ];

  selectedItem : Item;

  idCounter : number = 2;

  onSelect(item : Item) : void{
    this.selectedItem = item;
  }

  addItem() : void {
    this.idCounter += 1;
    let tmp : Item = {id: this.idCounter, name: "new Item", quantity: 0, unit: "unit"};
    this.items.push(tmp);
  }

  removeItem(item : Item) : void {
    let idx : number = this.items.indexOf(item);
    if (idx !== -1) {
      this.items.splice(idx, 1);
    }
  }

  constructor() { }

  ngOnInit() {
  }
  
}