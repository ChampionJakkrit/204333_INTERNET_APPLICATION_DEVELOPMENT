export class Item {
  id: number;
  name: string;
  quantity: number;
  unit: string;
}