import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClientInMemoryWebApiModule } from 'angular-in-memory-web-api';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { TimeAgoPipe } from 'time-ago-pipe';

import { AppComponent } from './app.component';
import { HelloComponent } from './hello.component';
import { InMemoryDataService } from './in-memory-data.service';
import { TweetService } from './tweet.service';
import { DisplayTweetComponent } from './display-tweet/display-tweet.component';
import { AddTweetComponent } from './add-tweet/add-tweet.component';
import { LoginComponent } from './login/login.component';
import { NavigationComponent } from './navigation/navigation.component';
import { AuthGuard } from './auth.guard';
import { AuthService } from './auth.service';
import { TimelineComponent } from './timeline/timeline.component';
import { UpvoteService } from './upvote.service';
import { UpvoteComponent } from './upvote/upvote.component';
import { DeleteComponent } from './delete/delete.component';
import { AngularFireModule } from '@angular/fire';
import { AngularFireDatabaseModule } from '@angular/fire/database';
import { AngularFirestore } from '@angular/fire/firestore';
import { environment } from './environment';

@NgModule({
  imports:      [ 
    BrowserModule, 
    FormsModule,
    HttpClientModule,
    HttpClientInMemoryWebApiModule.forRoot(InMemoryDataService,{dataEncapsulation:false}),
    ReactiveFormsModule,
    RouterModule.forRoot([
      {path:'',component:TimelineComponent},
      {path:'tweet',component:AddTweetComponent, canActivate:[AuthGuard]},
      {path:'login',component:LoginComponent}
    ]),
    AngularFireModule.initializeApp(environment.firebaseConfig),
    AngularFireDatabaseModule
  ],
  declarations: [ AppComponent, HelloComponent, DisplayTweetComponent, AddTweetComponent, LoginComponent, NavigationComponent, TimelineComponent, UpvoteComponent, TimeAgoPipe, DeleteComponent ],
  bootstrap:    [ AppComponent ],
  providers: [InMemoryDataService, TweetService, AuthService, UpvoteService, AngularFirestore]
})
export class AppModule { }
