import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators} from '@angular/forms';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(
    private route: Router,
    private form : FormBuilder,   
    private auth : AuthService  
  ) { }

  loginForm: FormGroup;  

  ngOnInit() {
    this.loginForm = this.form.group({
      username: ['',Validators.required]
    })
    this.auth.logout();
  }

  get f() { return this.loginForm.controls; }  

  login() {
    if(!this.loginForm.invalid) {
      this.auth.login(this.f.username.value);  
      this.route.navigate(['']);  
    }
  }

}