import { Component, OnInit, Input } from '@angular/core';
import { Tweet } from '../tweet';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-display-tweet',
  templateUrl: './display-tweet.component.html',
  styleUrls: ['./display-tweet.component.css']
})
export class DisplayTweetComponent implements OnInit {

  constructor( 
    private auth : AuthService
  ) { }

  @Input() tweet : Tweet;
  isLoggedIn;
  name;

  ngOnInit() {
    this.auth.isLoggedIn.subscribe(val => this.isLoggedIn = val);
    this.auth.username.subscribe(val => this.name = val);
    if (localStorage.getItem("isLoggedIn")==="true") {
      this.isLoggedIn = true;
      this.name = localStorage.getItem("username");
    }
  }

}