import { Component, OnInit, Input } from '@angular/core';
import { FirebaseService } from '../firebase.service';

@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent implements OnInit {

  constructor(
    private fServ : FirebaseService
  ) { }

  @Input() voteId : string;

  ngOnInit() {
  }

  delete() {
    this.fServ.deleteTweet(this.voteId);
  }

}