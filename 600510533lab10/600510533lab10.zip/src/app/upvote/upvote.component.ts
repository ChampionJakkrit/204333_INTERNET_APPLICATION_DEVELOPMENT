import { Component, OnInit, Input } from '@angular/core';
import { UpvoteService } from '../upvote.service';
import { AuthService } from '../auth.service';
import { FirebaseService } from '../firebase.service';

@Component({
  selector: 'app-upvote',
  templateUrl: './upvote.component.html',
  styleUrls: ['./upvote.component.css']
})
export class UpvoteComponent implements OnInit {

  constructor(
    private uServ : UpvoteService,
    private auth : AuthService,
    private fServ : FirebaseService
  ) { }

  @Input() voters;
  @Input() voteId;

  name;
  votes;
  userVote;
  isLoggedIn;
  s;

  ngOnInit() {
    this.auth.isLoggedIn.subscribe(val => this.isLoggedIn = val);
    this.auth.username.subscribe(val => this.name = val);
    if (localStorage.getItem("isLoggedIn")==="true") {
      this.isLoggedIn = true;
      this.name = localStorage.getItem("username");
    }
    this.votes = this.voters.length;
    this.userVote = this.voters.includes(this.name);
    this.updateColor();
  }

  vote() {
    this.userVote = !this.userVote;
    this.fServ.updateVote(this.voteId,this.name,this.userVote);
    this.updateColor();
  }

  updateColor() {
    if(this.userVote)
      this.s = "green";
    else
      this.s = "gray";
  }

}