import { Component, OnInit } from '@angular/core';
import { TweetService } from '../tweet.service';
import { FormControl, FormGroup, Validators} from '@angular/forms';
import { Router } from '@angular/router';
import { FirebaseService } from '../firebase.service';
import { AngularFireAuth } from "@angular/fire/auth";

@Component({
  selector: 'app-add-tweet',
  templateUrl: './add-tweet.component.html',
  styleUrls: ['./add-tweet.component.css']
})
export class AddTweetComponent implements OnInit {

  constructor(
    private tServ : TweetService,
    private route : Router,
    private fServ : FirebaseService,
    private afAuth : AngularFireAuth
  ) { }

  form = new FormGroup({
    msg : new FormControl(''),
  });
  username : string;

  ngOnInit() {
    this.afAuth.auth.onAuthStateChanged(user => {
      if (user) {
        var displayName = user.displayName;
        var email = user.email;
        var emailVerified = user.emailVerified;
        var photoURL = user.photoURL;
        var isAnonymous = user.isAnonymous;
        var uid = user.uid;
        var providerData = user.providerData;
        this.username = user.email;
      } else {
        this.username = "";
      }
    });
  }

  onSubmit() {
    this.fServ.addTweet(this.username,this.form.value.msg);
    this.route.navigate(['']);
  }

}