import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router'
import { AngularFireAuth } from '@angular/fire/auth';

@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.css']
})
export class NavigationComponent implements OnInit {

  constructor(
    private auth : AuthService,
    private route : Router,
    private afAuth : AngularFireAuth
  ) { }

  isLoggedIn : boolean;

  ngOnInit() {
    this.afAuth.auth.onAuthStateChanged((user) => {
      if (user) {
        this.isLoggedIn = true;
        console.log(this.isLoggedIn);
      } else {
        this.isLoggedIn = false;
        console.log(this.isLoggedIn);
      }
    });
  }

  logout() {
    this.afAuth.auth.signOut();
    this.route.navigate(['']);
  }

}