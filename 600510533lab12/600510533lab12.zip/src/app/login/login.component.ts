import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, FormGroup, Validators} from '@angular/forms';
import { AuthService } from '../auth.service';
import { AngularFireAuth } from "@angular/fire/auth";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(
    private route: Router,
    private auth : AuthService,
    private afAuth : AngularFireAuth
  ) { }

  form = new FormGroup({
    email : new FormControl(''),
    pwd : new FormControl('')
  }); 

  ngOnInit() {
    this.afAuth.auth.signOut();
  }

  login() {
    this.afAuth.auth.signInWithEmailAndPassword(this.form.value.email,this.form.value.pwd).catch(function(error) {
      window.alert(error.message);
    });
    this.route.navigate(['']);
  }

}