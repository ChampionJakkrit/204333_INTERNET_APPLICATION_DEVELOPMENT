import { Component, OnInit, Input } from '@angular/core';
import { TweetService } from '../tweet.service';
import { AuthService } from '../auth.service'
import { Tweet } from '../tweet';

@Component({
  selector: 'app-display-tweet',
  templateUrl: './display-tweet.component.html',
  styleUrls: ['./display-tweet.component.css']
})
export class DisplayTweetComponent implements OnInit {
  @Input() tweet : Tweet;

  tweets : Tweet[];
  currentUser: string

  constructor() { }

  ngOnInit() {

  }

  /*deleteTweet(id : number) {
    this.tServ.deleteTweets(id).subscribe();
    this.tServ.getTweets().subscribe(val => this.tweets = val);
  
    
  }*/
  

}
