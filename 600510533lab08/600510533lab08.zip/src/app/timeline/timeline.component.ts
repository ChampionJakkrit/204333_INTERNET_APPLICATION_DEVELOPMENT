import { Component, OnInit } from '@angular/core';
import { Tweet } from '../tweet';
import { TweetService } from '../tweet.service';

@Component({
  selector: 'app-timeline',
  templateUrl: './timeline.component.html',
  styleUrls: ['./timeline.component.css']
})
export class TimelineComponent implements OnInit {
  tweets : Tweet[];
  constructor(
    private tServ : TweetService
  ) { }

  ngOnInit() {
    this.tServ.getTweets().subscribe(val => this.tweets = val);
  }

}