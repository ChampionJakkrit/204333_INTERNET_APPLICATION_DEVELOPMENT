import { Component, OnInit } from '@angular/core';
import { TweetService } from '../tweet.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { Tweet } from '../tweet';

@Component({
  selector: 'app-add-tweet',
  templateUrl: './add-tweet.component.html',
  styleUrls: ['./add-tweet.component.css']
})
export class AddTweetComponent implements OnInit {

  constructor(
    private tServ : TweetService,
    private router : Router
  ) { }

  form = new FormGroup({
    msg : new FormControl(''),
  });

  name : string;

  ngOnInit() {
    this.name= localStorage.getItem("username");
  }

  onSubmit() {
    this.tServ.addTweet(this.name,this.form.value.msg)
    .subscribe();
    this.router.navigate(['']);
  }

}