export class Tweet {
  id: number;
  name: string;
  msg: string;
  date: Date;
}