import { Component, OnInit, Input } from '@angular/core';
import { UpvoteService } from '../upvote.service';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-upvote',
  templateUrl: './upvote.component.html',
  styleUrls: ['./upvote.component.css']
})
export class UpvoteComponent implements OnInit {

  constructor(
    private uServ : UpvoteService,
    private auth : AuthService
  ) { }

  @Input() id : number;

  username;
  upvote; // Upvote Object
  votes; // total number of votes
  userVote; // current vote
  isLoggedIn; // check for login

  ngOnInit() {
    // Authorization
    this.auth.isLoggedIn.subscribe(val => this.isLoggedIn = val);
    this.auth.username.subscribe(val => this.username = val);
    if(localStorage.getItem("isLoggedIn")==="true") {
      this.isLoggedIn = true;
      this.username = localStorage.getItem("username");
    }

    // Get Upvote
    this.uServ.getVote(this.id).subscribe(
      val => {
        this.upvote = val
        if(this.username!==undefined) this.userVote = val[this.username]
        this.sum(val)
      },
      error => {
        this.votes = 0
        this.upvote = {id:this.id}
      }
    );
  }

  sum(obj) {
    var sum = 0;
    for(var el in obj)
      if(obj.hasOwnProperty(el))
        sum += parseFloat(obj[el]);
    this.votes = sum - obj["id"];
  }

  vote() {
    // Update vote
    if(this.userVote===undefined) {
      this.userVote = 1;
      this.upvote[this.username] = 1;
    } else {
      let newVote = this.userVote == 1 ? 0 : 1;
      this.userVote = newVote;
      this.upvote[this.username] = newVote;
    }

    // Update Vote Service
    this.uServ.updateVote(this.upvote).subscribe();
    this.sum(this.upvote);
  }

  status() {
    if(this.userVote==1) {
      this.s = "green";
    } else {
      this.s = "black";
    }
  }
}