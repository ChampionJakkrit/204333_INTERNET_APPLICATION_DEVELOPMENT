import { Component, OnInit } from '@angular/core';
import { TweetService } from '../tweet.service';
import { Tweet } from '../tweet';

@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent implements OnInit {

  tweets : Tweet[];

  constructor(
    private tServ : TweetService
  ) { }

  ngOnInit() {
  }
  
  delete(id:number) {
    const url = `api/tweets/${id}`;
    this.tServ.deleteTweet(url).subscribe();
    this.tServ.getTweets()
    .subscribe(tweets => this.tweets = tweets);
  }

}